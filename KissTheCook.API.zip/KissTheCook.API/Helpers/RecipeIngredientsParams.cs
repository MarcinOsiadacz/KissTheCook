﻿using KissTheCook.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KissTheCook.API.Helpers
{
    public class RecipeIngredientsParams
    {
        public Ingredient[] Ingredients { get; set; }
    }
}
