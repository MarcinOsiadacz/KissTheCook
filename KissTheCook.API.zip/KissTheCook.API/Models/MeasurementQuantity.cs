﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Threading.Tasks;

namespace KissTheCook.API.Models
{
    public class MeasurementQuantity : AbstractEntity
    {
        public string Amount { get; set; }
    }
}
