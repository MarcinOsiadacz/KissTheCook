﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KissTheCook.API.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace KissTheCook.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MeasurementUnitsController : ControllerBase
    {
        private readonly ICookingRepository _cookingRepository;

        public MeasurementUnitsController(ICookingRepository cookingRepository)
        {
            _cookingRepository = cookingRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetMeasurementUnits()
        {
            return Ok(await _cookingRepository.GetMeasurementUnits());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetMeasurementUnit(int id)
        {
            return Ok(await _cookingRepository.GetMeasurementUnit(id));
        }
    }
}
