﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KissTheCook.API.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace KissTheCook.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MeasurementQuantitiesController : ControllerBase
    {
        private readonly ICookingRepository _cookingRepository;

        public MeasurementQuantitiesController(ICookingRepository cookingRepository)
        {
            _cookingRepository = cookingRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetMeasurementQuantities()
        {
            return Ok(await _cookingRepository.GetMeasurementQuantities());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetMeasurementQuantity(int id)
        {
            return Ok(await _cookingRepository.GetMeasurementQuantity(id));
        }
    }
}
