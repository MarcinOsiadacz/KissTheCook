﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KissTheCook.API.Data;
using KissTheCook.API.Helpers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace KissTheCook.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RecipesController : ControllerBase
    {
        private readonly ICookingRepository _cookingRepository;

        public RecipesController(ICookingRepository cookingRepository)
        {
            _cookingRepository = cookingRepository;
        }
        
        [HttpGet]
        public async Task<IActionResult> GetRecipes([FromBody] RecipeParams @params)
        {
            var recipesToReturn = await _cookingRepository.GetRecipes(@params);
            
            return Ok(recipesToReturn);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetRecipe(int id)
        {
            return Ok(await _cookingRepository.GetRecipe(id));
        }
    }
}
