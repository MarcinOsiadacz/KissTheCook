﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KissTheCook.API.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace KissTheCook.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IngredientsController : ControllerBase
    {
        private readonly ICookingRepository _cookingRepository;

        public IngredientsController(ICookingRepository cookingRepository)
        {
            _cookingRepository = cookingRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetIngredients()
        {
            return Ok(await _cookingRepository.GetIngredients());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetIngredient(int id)
        {
            return Ok(await _cookingRepository.GetIngredient(id));
        }
    }
}
